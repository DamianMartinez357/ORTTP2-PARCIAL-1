import dotenv from 'dotenv'

dotenv.config()

const PORT = 8080
const STRCON = process.env.STRCON
const MODO_PERSISTENCIA = process.env.MODO_PERSISTENCIA || 'MONGO'   // FS - MONGO
const BASE = process.env.BASE

export default {
    PORT,
    STRCON,
    MODO_PERSISTENCIA,
    BASE
}