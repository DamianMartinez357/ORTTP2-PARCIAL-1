import ApiNumeros from '../api/numeros.js'


class ControladorNumeros {

    constructor() {
        this.apiNumeros = new ApiNumeros()
    }
    postNumero = async (req,res) => {
        const numero = req.body
        res.json(await this.apiNumeros.postNumero(numero))
    }
    getNumeros = async (req,res) => {
        res.json (await this.apiNumeros.getNumeros())
    }
    getPromedio = async (req,res) => {
        res.json(await this.apiNumeros.getPromedio())
    }
    getMinMax = async (req,res) => {
        res.json(await this.apiNumeros.getMinMax())
    }
    getCantidad = async (req,res) => {
        res.json(await this.apiNumeros.getCantidad())
    }
}
export default ControladorNumeros