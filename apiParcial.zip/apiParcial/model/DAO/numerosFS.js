import fs from 'fs'


/* fs.readFile('./numeros.dat','utf-8',(error,lectura) => {
fs.writeFile('./numeros.dat', JSON.stringify(info, null,'\t'),'utf-8', (err) => {
    
    });
})

console.log('')
 */

class NumerosFSDAO {

    constructor() {
        this.numeros = [
            {numero: 32},
            {numero: 33},
        ]
    }


    
    //ARRAY JSON STRINGIFY
    //LEER JSON.PARSE

    postNumero
    getNumeros
    getPromedio
    getMinMax
    getCantidad

    
    }

export default NumerosFSDAO
