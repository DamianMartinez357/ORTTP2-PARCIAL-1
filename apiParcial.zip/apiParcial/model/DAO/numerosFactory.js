import NumerosFSDAO from './numerosFS.js'
import NumerosMongoDAO from './numerosMongoDB.js'

class NumerosFactoryDAO {
    static get(tipo) {
        switch(tipo) {
            case 'MEM' :
                console.log(' ***** Persistiendo en Archivos ***** ')
                return new NumerosFSDAO()

            case 'MONGO' :
                console.log(' ***** Persistiendo en MongoDB ***** ')
                return new NumerosMongoDAO()

            default: 
                console.log(' ***** Persistiendo en default (Archivos) ***** ')
                return new NumerosFSDAO()
        }
    }
}
export default NumerosFactoryDAO