import CnxMongoDB from '../DB.js'
class NumerosMongoDAO {
      

    postNumero = async numero => {
        if(!CnxMongoDB.connection) return {}
        await CnxMongoDB.db.collection('numeros').insertOne(numero)
        return numero    
    }
    getNumeros = async ()  => {
        if(!CnxMongoDB.connection) return []
        try {
            let numeros = await CnxMongoDB.db.collection('numeros').find({}).toArray()
            return numeros
        }
        catch {
            return []
        }
    }
     getPromedio = async ()  => {
        if(!CnxMongoDB.connection) return []
        try {
            let promedio = await CnxMongoDB.db.collection('numeros').aggregate([{$group: { _id: null, "Promedio": {$avg: '$numero'}}}]).toArray()
            return promedio
        }
        catch {
            return []
        }
    }

    getMinMax = async ()  => {
        if(!CnxMongoDB.connection) return []
        try {

            let numeros = await CnxMongoDB.db.collection('numeros').find({}).toArray()
            var min = Math.min(numeros)
            var max = Math.max(numeros)
            return {min,max}
        }
        catch {
            return []
        }
    }
    
    getCantidad = async ()  => {
        if(!CnxMongoDB.connection) return []
        try {
            var cantidad = await CnxMongoDB.db.collection('numeros').find().count()
            return cantidad
        }
        catch {
            return []
        }
    }
}

export default NumerosMongoDAO
