import config from '../config.js'
import NumerosFactoryDAO from '../model/DAO/numerosFactory.js'


class ApiNumeros {
    constructor() {

        this.numerosModel = NumerosFactoryDAO.get(config.MODO_PERSISTENCIA)
    }

    postNumero = async numero => {
    return await this.numerosModel.postNumero(numero)
    }
    getNumeros = async id => {
        return await this.numerosModel.getNumeros()
    }
    getPromedio = async id => {
        return await this.numerosModel.getPromedio()
    }
    getMinMax = async id => {
        return await this.numerosModel.getMinMax()
    }
    getCantidad = async id => {
        return await this.numerosModel.getCantidad()
    }

}

export default ApiNumeros